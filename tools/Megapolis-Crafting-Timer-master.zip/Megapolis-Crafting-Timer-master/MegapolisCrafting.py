from datetime import datetime, timedelta

class MegapolisCrafting(object):
    pass
        

class GreenHouse(MegapolisCrafting):

    def returnGreenhouse(self):
        ''' Prints the finishing times for all crafting items in the Experimental Green House '''
        self.time = 'Current time: ' + str(datetime.now())
        print self.time
        self.fertilizer()
        print '------------------'
        print self.time
        self.sqrmelons()
        print '------------------'
        print self.time
        self.soilpurif()
        print '------------------'
        print self.time
        self.irrigation()
  
    def fertilizer(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 8
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Fertilizer completion: ', fintime
    
    def sqrmelons(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 36
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Square Melon completion: ', fintime

    def soilpurif(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 5
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Soil purifier completion: ', fintime

    def irrigation(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 20
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Irrigation system completion: ', fintime


class Dealership(MegapolisCrafting):

    def returnDealership(self):
        ''' Prints the finishing times for all crafting items in the Car Dealership '''
        self.time = 'Current time: ' + str(datetime.now())
        print self.time
        self.sportsCar()
        print '------------------'
        print self.time
        self.glonass()
        print '------------------'
        print self.time
        self.electricCars()
        print '------------------'
        print self.time
        self.busses()

    def sportsCar(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 38
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Sports car completion: ', fintime

    def glonass(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 1
        fintime = datetime.now() + timedelta(hours=duration)
        print 'GLONASS station completion: ', fintime

    def electricCars(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 28
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Electric car completion: ', fintime

    def busses(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 24
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Bus completion: ', fintime


class HouseholdGoodsFacility(MegapolisCrafting):

    def returnHGF(self):
        ''' Prints the finishing times for all crafting items in the Household Goods Facility '''
        self.time = 'Current time: ' + str(datetime.now())
        print self.time
        self.venetianblinds()
        print '------------------'
        print self.time
        self.businesssuit()
        print '------------------'
        print self.time
        self.dvdgames()
        print '------------------'
        print self.time
        self.kettles()

    def venetianblinds(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 0.05
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Venetian blinds completion: ', fintime

    def businesssuit(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 0.33
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Business suits completion: ', fintime

    def dvdgames(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 24
        fintime = datetime.now() + timedelta(hours=duration)
        print 'DVD games completion: ', fintime

    def kettles(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 2.5
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Electric kettles completion: ', fintime


class HouseholdGoodsStore(MegapolisCrafting):

    
    def returnHGS(self):
        ''' Prints the finishing times for all crafting items in the Household Goods Store '''
        self.time = 'Current time: ' + str(datetime.now())
        print self.time
        self.freshveggie()
        print '------------------'
        print self.time
        self.coffebeans()
        print '------------------'
        print self.time
        self.pastry()
        print '------------------'
        print self.time
        self.popcorn()
        print '------------------'
        print self.time
        self.kitchenware()
        print '------------------'
        print self.time
        self.detergents()
        print '------------------'
        print self.time
        self.fertilizers()
        print '------------------'
        print self.time
        self.chips()

    def freshveggie(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 0.05
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Fresh vegetables completion: ', fintime

    def coffebeans(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 14
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Coffee beans completion: ', fintime

    def pastry(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 10
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Pastry completion: ', fintime

    def popcorn(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 1
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Popcorn completion: ', fintime

    def kitchenware(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 4
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Kitchenware completion: ', fintime

    def detergents(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 1
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Household detergents completion: ', fintime

    def fertilizers(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 0.5
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Garden fertilizers completion: ', fintime

    def chips(self):
        ''' Return the completion time for crafting this item based on the current system time. '''
        # Duration in hours.
        duration = 0.25
        fintime = datetime.now() + timedelta(hours=duration)
        print 'Chips completion: ', fintime


g = GreenHouse()
d = Dealership()
hgf = HouseholdGoodsFacility()
hgs = HouseholdGoodsStore()


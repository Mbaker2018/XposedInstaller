Megapolis-Crafting-Timer
========================
A python program that calculates the completion time of various Megapolis crafting items. There are four of the production facilities included at this time(Greenhouse, Car Dealership, Household Goods Store, and Household Goods Facility. Four instance are pre-defined for these:

* g = GreenHouse()
* d = Dealership()
* hgf = HouseholdGoodsFacility()
* hgs = HouseholdGoodsStore()

To find out what time a given facility would complete any of its crafting items one would input, g.returnGreenhouse(), d.returnDealership(), hgf.returnHGF, or hgs.returnHGS for each respectivly.

Todo
* Finish checking for typos and bugs
* Add the rest of the production facilities

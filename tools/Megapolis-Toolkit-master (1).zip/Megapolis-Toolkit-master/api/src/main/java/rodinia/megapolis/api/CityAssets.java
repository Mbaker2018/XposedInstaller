package rodinia.megapolis.api;

import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Used to download City Asset information from cloudfront
 * Would become more  if combined with information from YAML files
 * @see @see rodinia.megapolis.api.entity.CityItem
 */
public class CityAssets
{
   public final static String cloudfront_host = "d2u4irehk8sjh0";
   public static int current_rev = 4361;

   public static String file_city_options = "city_options.yml";
   public static String file_city_hierarchy = "city_hierarchy.yml";
   public static String file_city_items = "city_items.bin"; // ToDo: how to decode this file????

   public static Logger logger = Logger.getLogger(CityAssets.class.getName());

   public static Map<String, Object> getFileAsYamlMap(final String filename) throws IOException
   {
      return getFileAsYamlMap(filename, current_rev);
   }

   public static Map<String, Object> getFileAsYamlMap(final String filename, final int rev) throws IOException
   {
      logger.info("Downloading: " + filename);

      InputStream is = getFileAsStream(filename, rev);
      try
      {
         Yaml yaml = new Yaml();
         return (Map<String, Object>) yaml.load(is);
      }
      finally
      {
         is.close();
      }
   }

   public static InputStream getFileAsStream(final String filename, final int rev) throws IOException
   {
      final URL url = makeUrl(filename, rev);
      return url.openStream();
   }

   public static URL makeUrl(final String file, final int rev)
   {
      return makeUrl(cloudfront_host, file, rev);
   }

   public static URL makeUrl(final String host, final String file, final int rev)
   {
      final String url_city_options = String.format("http://%s.cloudfront.net/mobile_assets_city_int/%s?rev=%d", host, file, rev);
      try
      {
         return new URL(url_city_options);
      }
      catch (MalformedURLException e)
      {
         throw new Error(e);
      }
   }
}

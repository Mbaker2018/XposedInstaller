package rodinia.megapolis.api;

/**
 * Created by Rodinia on 30-8-2014.
 */
public interface IUserId
{
   public long getId();

   public String getToken();
}

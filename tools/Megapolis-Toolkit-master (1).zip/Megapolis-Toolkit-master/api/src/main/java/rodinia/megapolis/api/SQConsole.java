package rodinia.megapolis.api;

import rodinia.megapolis.api.command.Command;
import rodinia.megapolis.api.command.CommandList;
import rodinia.megapolis.api.command.CommandSyntax;

import java.io.*;
import java.text.ParseException;

/**
 * Created by Rodinia on 30-8-2014.
 */
public class SQConsole
{
   final InputStream consoleIn;
   final PrintStream consoleOut;

   final SocialQuantumClient sqc;

   CommandList commandList;

   public static void main(final String[] args)
   {
      try
      {
         new SQConsole(System.in, System.out).runConsole();
      }
      catch (IOException e)
      {
         e.printStackTrace();
      }
   }

   public SQConsole(final InputStream consoleIn, final PrintStream out)
   {
      this.consoleIn = consoleIn;
      this.consoleOut = out;

      this.commandList = new CommandList();

      this.sqc = SocialQuantumClient.connectToRandomHost();
   }

   public void runConsole() throws IOException
   {
      BufferedReader br = new BufferedReader(new InputStreamReader(this.consoleIn));
      this.consoleOut.println("Megapolis API Console.");
      do
      {
         // Command line
         this.consoleOut.print("# ");
         this.consoleOut.flush();

         String cmdLine = br.readLine();
         if(!cmdLine.isEmpty())
         {
            try
            {
               this.executeCommand(cmdLine);
            }
            catch (ParseException e)
            {
               e.printStackTrace(this.consoleOut);
            }
         }
      }
      while(true);
   }

   private void executeCommand(String cmdLine) throws ParseException
   {
      if(cmdLine.equals("?"))
      {
         for(CommandSyntax syntax : this.commandList.getCommands())
         {
            this.consoleOut.println(syntax);
         }
      }
      else
      {
         final Command command = Command.parse(cmdLine);
         // ToDo: this.sqc.postCommand(command);
      }
   }
}

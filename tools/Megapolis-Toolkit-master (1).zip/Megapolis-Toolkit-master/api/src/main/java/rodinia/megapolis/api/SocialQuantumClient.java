package rodinia.megapolis.api;

import com.fasterxml.jackson.databind.ObjectMapper;


import org.glassfish.jersey.client.ClientConfig;

import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.RequestEntityProcessing;
import rodinia.megapolis.api.command.Command;

import rodinia.megapolis.api.entity.Country;
import rodinia.megapolis.api.entity.Friend;

import rodinia.megapolis.api.entity.json.UserId;
import rodinia.megapolis.api.request.*;

import javax.ws.rs.client.*;

import javax.ws.rs.core.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.*;


/**
 * Created by Rodinia on 18-8-2014.
 */
public class SocialQuantumClient
{
   public static String method_find_user_id = "find_user_id";

   public static String method_associate = "associate";

   /**
    * For downloading initial country (city) data:
    */
   public static String method_get_user_stat = "get_user_stat";

   /**
    * Used for posting commands, and receiving updates
    */
   public static String method_check_and_perform = "check_and_perform";

   /**
    * Used to enable buddies
    */
   public static String method_process = "process";

   /**
    * Almost the same as "find_user_id", does not use "no_create"
    */
   public static String method_associated = "associated"; // ToDo: is the method used


   private final static String param_name_rn = "rn";

   private int rn = 0;
   private int rollCounter = 0;
   private String host;
   private WebTarget target;

   private boolean print_postRequest = false;


   public SocialQuantumClient(String host)
   {
      System.out.println("Initializing Social Quantum Client using host: " + host);

      this.host = host;

      ClientConfig config = new ClientConfig();
      config.property(ClientProperties.REQUEST_ENTITY_PROCESSING, RequestEntityProcessing.BUFFERED); // Disable chunked encoding (use buffered)

      Client client = ClientBuilder.newBuilder().withConfig(config).build();

      this.target = client.target(this.getUrl());
   }

   public Country postUserStat(IUserId profile, int room_id) throws IOException
   {
      UserStatRequest userStatRequest = new UserStatRequest(profile, room_id);
      return this.postUserStat(userStatRequest);
   }

   public Country postUserStat(UserProfile profile, int room_id, Friend friend) throws IOException
   {
      return postUserStat(profile, room_id, friend.id);
   }

   public Country postUserStat(UserProfile profile, int room_id, long friendUserId) throws IOException
   {
      UserStatRequest userStatRequest = new UserStatRequest(profile, room_id, friendUserId);
      return this.postUserStat(userStatRequest);
   }

   public Country parseAndPostCommand(UserProfile profile, int room_id, BufferedReader reader, boolean useQueue) throws IOException, ParseException
   {
      String cmdLine;
      LinkedList<Command> cmdList = new LinkedList<Command>();
      while ((cmdLine = reader.readLine()) != null)
      {
         cmdLine = cmdLine.trim();
         if(cmdLine.startsWith("#") || cmdLine.startsWith("//"))
         {
            System.out.println(cmdLine);
         }
         else if(!cmdLine.isEmpty())
         {
            Command cmd = Command.parse(cmdLine);
            cmdList.add(cmd);
         }
      }

      if(useQueue)
      {
         return postCommand(profile, room_id, cmdList);
      }
      else
      {
         Country country = null;
         for (Command cmd : cmdList)
         {
            country = postCommand(profile, room_id, cmd);
         }
         return country;
      }
   }

   /**
    * Parse and run given command
    * @param profile User account profile
    * @param room_id Room ID
    * @param command command, e.g.:
    * @return
    * @throws IOException
    * @throws ParseException
    */
   public Country parseAndPostCommand(UserProfile profile, int room_id, String command) throws IOException, ParseException
   {
      return this.postCommand(profile, room_id, Command.parse(command));
   }

   public Country postCommand(UserProfile profile, int room_id, Command command) throws IOException
   {
      System.out.println("Post single command: " + command.toString());
      command.addArgument(Command.arg_roll_counter, Integer.toString(this.rollCounter++));
      Form request = CachedCommandRequest.make(profile, room_id, command);
      return this.postCheckAndPerform(request);
      //Form request = CommandRequest.make(profile, room_id, command);
      //return this.process(request);
   }

   public Country postCommand(UserProfile profile, int room_id, Collection<Command> commands) throws IOException
   {
      return this.postCommand(profile, room_id, commands.toArray(new Command[commands.size()]));
   }

   /**
    * Looks like of to many commands are send in one POST-request, an HTTP response status 411 is returned.
    * Not sure if it is really the number of commands, or the size of the post.
    */
   @Deprecated // issue was caused by chunked transfer encoding
   public static int max_commands_per_post = 100;

   public Country postCommand(UserProfile profile, int room_id, Command... commands) throws IOException
   {
      System.out.println("post cached command: ");
      for(Command cmd : commands)
      {
         cmd.addArgument(Command.arg_roll_counter, Integer.toString(this.rollCounter++));
         System.out.println("  " + cmd.toString());
      }
      CachedCommandRequest request = new CachedCommandRequest(profile, room_id);
      int cmdCount = 0;
      for(Command cmd : commands)
      {
         request.add(cmd);
         if(++cmdCount == max_commands_per_post)
         {
            this.postCheckAndPerform(request);
            request = new CachedCommandRequest(profile, room_id);
            cmdCount = 0;
         }
      }
      return this.postCheckAndPerform(request);
   }

   private Country postUserStat(UserStatRequest request) throws IOException
   {
      return this.postCountryRequest(method_get_user_stat, request);
   }

   private Country postCheckAndPerform(Form formRequest) throws IOException
   {
      return this.postCountryRequest(method_check_and_perform, formRequest);
   }

   private Country process(Form formRequest) throws IOException
   {
      return this.postCountryRequest(method_process, formRequest);
   }

   public UserId findUserIdByGameCenterId(long gameCenterId) throws IOException
   {
      return findUserId( FindUserIdRequest.fromGameCenterId(gameCenterId) );
   }

   private UserId findUserId(FindUserIdRequest request) throws IOException
   {
      return getUserId(method_find_user_id, request);
   }

   private UserId getUserId(final String method, Form request) throws IOException
   {
      Response response = postRequest(method, request);
      if(response.getStatus() == 200)
      {
         return new ObjectMapper().readValue((InputStream) response.getEntity(), UserId.class);
      }
      throw new IOException("  Post response status = " + response.getStatus());
   }

   private Country postCountryRequest(final String method, final Form request) throws IOException
   {
      Response response = this.postRequest(method, request);
      if(response.getStatus() == 200)
      {
         Country country = response.readEntity(Country.class);
         System.out.println("Country: " + country);
         return country;
      }
      throw new IOException("  Post response status = " + response.getStatus());
   }

   private Response postRequest(final String method, final Form request) throws IOException
   {
      final int rnSeqNum = rn++;
      request.param(param_name_rn, Integer.toString(rnSeqNum));

      if (this.print_postRequest)
      {
         // Print request
         System.out.println("Post[#" + rnSeqNum + "]: " + method + ":");
         for (Map.Entry<String, List<String>> entry : request.asMap().entrySet())
         {
            System.out.println("  " + entry.getKey() + ": " + entry.getValue());
         }
      }

      // Post request
      Invocation.Builder builder = this.target.path(method).request(); // ToDo: ensure post content-length is included to avoid HTTP error 411
      return builder.post(Entity.form(request.asMap())); // For some reason the request cannot be passed as Form object
   }

   public String getUrl()
   {
      return "http://" + host;
   }

   /**
    * @return host like nweb07.socialquantum.com
    */
   public static SocialQuantumClient connectToRandomHost()
   {
      final String host = getRandomHost();
      return new SocialQuantumClient(host);
   }

   private static String getRandomHost()
   {
      final int hostNr = randInt(1, 30);
      return String.format("nweb%02d.socialquantum.com", hostNr);
   }

   /**
    * Returns a pseudo-random number between min and max, inclusive.
    * The difference between min and max can be at most
    * <code>Integer.MAX_VALUE - 1</code>.
    *
    * @param min Minimum value
    * @param max Maximum value.  Must be greater than min.
    * @return Integer between min and max, inclusive.
    * @see java.util.Random#nextInt(int)
    */
   private static int randInt(int min, int max) {

      // NOTE: Usually this should be a field rather than a method
      // variable so that it is not re-seeded every call.
      Random rand = new Random();

      // nextInt is normally exclusive of the top value,
      // so add 1 to make it inclusive
      return rand.nextInt((max - min) + 1) + min;
   }

   /**
    * Very powerful command to switch Apple Game Center Player ID to existing giving Megapolis profile
    * @param gameCenterId Apple Game Center Player ID
    * @param profile
    * @return Userid existing player
    * @throws IOException
    */
   public UserId associate(long gameCenterId, IUserId profile) throws IOException
   {
      FindUserIdRequest request = FindUserIdRequest.fromGameCenterId(gameCenterId);

      request.param(UserRequest.param_userid, Long.toString(profile.getId()));
      request.param(UserRequest.param_sq_token, profile.getToken());
      return getUserId(method_associate, request);
   }

   public void changeHost()
   {
      this.host = getRandomHost();
   }
}

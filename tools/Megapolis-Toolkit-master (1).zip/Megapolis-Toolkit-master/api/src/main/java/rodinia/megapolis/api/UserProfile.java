package rodinia.megapolis.api;

/**
 * Created by Rodinia on 18-8-2014.
 */
public class UserProfile implements IUserId
{
   public static int default_priority = 100;

   /**
    * Depending on the network the authentication is slightly different
    * @see rodinia.megapolis.api.request.UserRequest
    */
   public enum NetworkType
   {
      Facebook,
      SocialQuantum
   }

   public long userId;
   public String userToken;
   public NetworkType networkType;
   public int priority;

   public UserProfile(long userId, String token)
   {
      this.userId = userId;
      this.userToken = token;
      this.networkType = determineNetworkType(userId);
      this.priority = default_priority;
   }

   public UserProfile(NetworkType networkType, long userId, String token, int priority)
   {
      this.userId = userId;
      this.userToken = token;
      this.networkType = networkType;
      this.priority = priority;
   }

   public UserProfile(NetworkType networkType, long userId, String token)
   {
      this(networkType, userId, token, 100);
   }

   @Override public long getId()
   {
      return this.userId;
   }

   @Override public String getToken()
   {
      return this.userToken;
   }

   public static NetworkType determineNetworkType(IUserId userProfile)
   {
      return determineNetworkType(userProfile.getId());
   }

   /**
    * It looks like positive ID's are used for Facebook accounts.
    * @param userId
    * @return Facebook or SocialQuantum
    */
   protected static NetworkType determineNetworkType(long userId)
   {
      return userId > 0 ? NetworkType.Facebook : NetworkType.SocialQuantum;
   }

   public String toString()
   {
      return "sqid=" + this.userId + "[" + (this.networkType==NetworkType.SocialQuantum ? "SQ" : "FB") + "] token=" + this.userToken;
   }

}

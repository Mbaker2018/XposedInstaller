package rodinia.megapolis.api.command;

import java.text.ParseException;
import java.util.Map;
import java.util.TreeMap;

/**
 * SQ command and available parameters
 * Created by Rodinia on 20-8-2014.
 */
public class Command
{
   public final String command;
   private final Map<String, String> args;
   public final static String arg_roll_counter="roll_counter";

   public Command(String command)
   {
      this.command = command;
      this.args = new TreeMap<String, String>();
   }

   public Command(String type, Map<String, String> args)
   {
      this.command = type;
      this.args = args;
   }

   public Map<String, String> getArguments()
   {
      return this.args;
   }

   public void parseArgument(String expression)
   {
      if(expression != null && !expression.isEmpty())
      {
         int index = expression.indexOf('=');
         if (index == -1)
         {
            this.addArgument(expression, null);
         }
         else
         {
            String key = expression.substring(0, index);
            String value = expression.substring(index + 1);
            this.addArgument(key, value);
         }
      }
   }

   public void addArgument(String key, String value)
   {
      if(key == null)
         throw new IllegalArgumentException("argument key cannot be null");
      if(key.isEmpty())
         throw new IllegalArgumentException("argument key cannot be empty");
      args.put(key, value);
   }

   public static Command parse(String expression) throws ParseException
   {
      String[] words = expression.trim().split(" ");
      return parse(words);
   }

   public static Command parse(String... words) throws ParseException
   {
      if (words.length > 0)
      {
         Command command = new Command(words[0]);
         for (int n = 1; n < words.length; ++n)
         {
            String word = words[n].trim();
            if(!word.isEmpty())
               command.parseArgument(words[n]);
         }
         return command;
      }
      throw new ParseException("Command missing", 0);
   }

   public String getCommand()
   {
      return this.command;
   }

   @Override
   public String toString()
   {
      String cmdLine = command;
      for(Map.Entry<String, String> arg : this.args.entrySet())
      {
         cmdLine += " " + arg.getKey() + "=" + arg.getValue();
      }
      return cmdLine;
   }
}

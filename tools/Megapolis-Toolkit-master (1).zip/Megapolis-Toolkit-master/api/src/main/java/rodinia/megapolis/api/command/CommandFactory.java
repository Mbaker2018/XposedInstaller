package rodinia.megapolis.api.command;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import rodinia.megapolis.api.IUserId;
import rodinia.megapolis.api.entity.CityItem;
import rodinia.megapolis.api.entity.Country;
import rodinia.megapolis.api.entity.Friend;
import rodinia.megapolis.api.entity.json.Transport;

import java.text.ParseException;
import java.util.Collection;

/**
 * Created by Rodinia on 18-8-2014.
 */
public class CommandFactory
{
   public static Command clean(int room_id, int item_id)
   {
      return makeCommand(CommandSyntax.clean.command, "room_id=" + room_id, "item_id=" + item_id);
   }

   /**
    * Buy gift, (material from class 'klass') for friend 'second_user_id'
    * See also:
    */
   public static Command gift_from_shop(final long second_user_id, final String klass)
   {
      return makeCommand(CommandSyntax.gift_from_shop.command, "klass=" + klass, "second_user_id=" + second_user_id);
   }

   public static Command invite_suggested_neighbors(long friend_id)
   {
      return send_request(friend_id, CommandSyntax.request_name_invite_suggested_neighbors);
   }

   public static Command send_request(long friend_id, String name)
   {
      return makeCommand(CommandSyntax.send_request.command, "name=" + name, "friend_id=" + friend_id);
   }

   public static Command commit_request_contract(final Friend friend, final String name, final int room_id, final int contact_id) throws JsonProcessingException
   {
      return makeCommand(CommandSyntax.commit_request.command, "name=" + name, "friend_id=" + friend.id, "room_id=" + room_id, "contact_id=" + contact_id);
   }

   public static Command commit_request(final Friend friend, final Collection<Transport> transport) throws JsonProcessingException
   {
      return commit_request(friend.id, transport);
   }

   public static Command commit_request(final long friend_id, final Collection<Transport> transport) throws JsonProcessingException
   {
      String json_transport = new ObjectMapper().writeValueAsString(transport);
      return makeCommand(CommandSyntax.commit_request.command, "name=bus_transport_request_back", "friend_id=" + friend_id, "transport=" + json_transport);
   }

   public static Command commit_request(final Friend friend, final String name) throws JsonProcessingException
   {
      return commit_request(friend.id, name);
   }

   public static Command commit_request(final long friend_id, final String name)
   {
      return makeCommand(CommandSyntax.commit_request.command, "name=" + name, "friend_id=" + friend_id);
   }

   public static Command say_thanks(final long friend_id)
   {
      return makeCommand(CommandSyntax.say_thanks.command, "friend_id=" + friend_id);
   }

   /**
    * Make command send gift from gifts.
    * See also: gift_from_shop
    * @param second_user_id friend
    * @param item_id material item id#
    * @return command
    */
   public static Command send_gift(final long second_user_id, final int item_id)
   {
      return send_gift(second_user_id, item_id, item_id);
   }

   public static Command send_gift(Friend friend, long item_id)
   {
      return send_gift(friend.id, item_id, item_id);
   }

   public static Command send_gift(long second_user_id, long item_id, long type_id)
   {
      //return makeCommand(CommandSyntax.send_gift.command, "second_user_id=" + second_user_id, "item_id=" + item_id, "type_id=" + type_id, "room_id=0");
      return makeCommand(CommandSyntax.commit_request.command, "name=send_gift", "friend_id=" + second_user_id, "item_id=" + item_id, "type_id=" + type_id);
   }

   public static Command tick(int item_id)
   {
      return makeCommand(CommandSyntax.tick.command, "item_id=" + item_id);
   }

   public static Command pick(Country country, CityItem item)
   {
      return pick(country.room_id, item.id);
   }

   public static Command pick(int room_id, int item_id)
   {
      return makeCommand(CommandSyntax.pick.command, "room_id=" + room_id, "item_id=" + item_id);
   }

   public static Command quest_accept(int room_id, int quest_id)
   {
      return makeCommand(CommandSyntax.quest_accept.command, "room_id=" + room_id, "quest_id=" + quest_id);
   }

   public static Command quest_inc_counter(int room_id, int quest_id)
   {
      return makeCommand(CommandSyntax.quest_inc_counter.command, "room_id=" + room_id, "quest_id=" + quest_id);
   }

   public static Command quest_complete(int room_id, int quest_id)
   {
      return makeCommand(CommandSyntax.quest_complete.command, "room_id=" + room_id, "quest_id=" + quest_id);
   }

   public static Command quest_inc_counter(int room_id, int quest_id, int counter, int count)
   {
      return makeCommand(CommandSyntax.quest_inc_counter.command, "room_id=" + room_id, "quest_id=" + quest_id, "counter=" + counter, "count=" + count);
   }

   public static Command help(Country friendCountry, CityItem item)
   {
      return help(friendCountry.owner_id, friendCountry.room_id, item.name, item.id);
   }

   public static Command help(long friend_id, int room_id, final String klass, int item_id)
   {
      return makeCommand(CommandSyntax.help.command, "friend_id=" + friend_id, "owner_id=" + friend_id, "room_id=" + room_id, "klass=" + klass, "item_id=" + item_id);
   }

   /**
    * Move gift to store-house
    * @param klass e.g. act_of_expanding
    */
   public static Command barn_gift(int item_id, String klass, long sender_user_id)
   {
      return makeCommand(CommandSyntax.barn_gift.command, "item_id=" + item_id, "klass=" +  klass, "sender_user_id=" + sender_user_id);
   }

   public static Command apply_help(long friend_id, int room_id, int item_id)
   {
      return makeCommand(CommandSyntax.apply_help.command, "friend_id=" + friend_id, "room_id=" + room_id, "item_id=" + item_id);
   }

   public static Command apply_help(Friend friend, int room_id, int item_id)
   {
      return apply_help(friend.id, room_id, item_id);
   }

   /**
    * Buy material for friend for given item
    * @param room_id room id
    * @param friend_id friend SQ player ID
    * @param klass Material class, e.g. office_dispatcher
    * @param item_id for which building (under construction)
    * See also gift_from_shop
    * @return constructed command
    */
   public static Command apply_to_friend(int room_id, final long friend_id, final String klass, int item_id)
   {
      return makeCommand(CommandSyntax.apply_to_friend.command, "room_id=" + room_id, "owner_id=" + friend_id, "friend_id=" + friend_id, "klass=" + klass, "item_id=" + item_id);
   }

   public static Command give_invite_window_bonus()
   {
      return makeCommand(CommandSyntax.give_invite_window_bonus.command);
   }

   public static Command pick_bus(int room_id, int item_id, int object_id)
   {
      return makeCommand(CommandSyntax.pick_bus.command, "room_id=" + room_id, "item_id=" + item_id, "object_id=" + object_id);
   }

   public static Command send_bus(int room_id, int item_id, int object_id)
   {
      return makeCommand(CommandSyntax.send_bus.command, "room_id=" + room_id, "item_id=" + item_id, "object_id=" + object_id);
   }

   public static Command put(int room_id, int item_id, String klass)
   {
      return makeCommand(CommandSyntax.put.command, "room_id=" + room_id, "item_id=" + item_id, "klass=" + klass);
   }

   public static Command level_up()
   {
      return makeCommand(CommandSyntax.level_up.command);
   }

   public static Command makeCommand(String... args)
   {
      try
      {
         return Command.parse(args);
      }
      catch (ParseException e)
      {
         throw new RuntimeException(e);
      }
   }



}

package rodinia.megapolis.api.command;

import java.util.*;

/**
 * List of available SQ commands
 * Created by Rodinia on 20-8-2014.
 */
public class CommandList
{
   private Map<String, CommandSyntax> commandList = new TreeMap<String, CommandSyntax>();

   public CommandList()
   {
      this.initCommands();
   }

   public void initCommands()
   {
      addCommand(CommandSyntax.apply_help);
      addCommand(CommandSyntax.apply_gift);
      addCommand(CommandSyntax.apply_item_from_barn);
      addCommand(CommandSyntax.apply_to_friend);
      addCommand(CommandSyntax.barn_gift);
      addCommand(CommandSyntax.clean);
      addCommand(CommandSyntax.create);
      addCommand(CommandSyntax.commit_request);
      addCommand(CommandSyntax.create);
      addCommand(CommandSyntax.gift_from_shop);
      addCommand(CommandSyntax.give_invite_window_bonus);
      addCommand(CommandSyntax.help);
      addCommand(CommandSyntax.mass_quest_inc_counter);
      addCommand(CommandSyntax.move);
      addCommand(CommandSyntax.pick);
      addCommand(CommandSyntax.put);
      addCommand(CommandSyntax.quest_accept);
      addCommand(CommandSyntax.quest_complete);
      addCommand(CommandSyntax.quest_inc_counter);
      addCommand(CommandSyntax.quest_list_accept);
      addCommand(CommandSyntax.receive_item_from_barn);
      addCommand(CommandSyntax.remove_from_wish_list);
      addCommand(CommandSyntax.say_thanks);
      addCommand(CommandSyntax.send_bus);
      addCommand(CommandSyntax.send_gift);
      addCommand(CommandSyntax.send_request);
      addCommand(CommandSyntax.suggest_neighbors);
      addCommand(CommandSyntax.tick);

      addCommand(CommandSyntax.mass_quest_inc_counter);
   }

   public Collection<CommandSyntax> getCommands()
   {
      return this.commandList.values();
   }

   private void addCommand(CommandSyntax command)
   {
      this.commandList.put(command.command, command);
   }
}

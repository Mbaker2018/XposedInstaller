package rodinia.megapolis.api.command;

/**
 * Aim of the Command Syntax is to have objects are to build knowledge what command syntax can be processed by SQ, and what is can do,
 * Note that this is far from complete.
 */
public class CommandSyntax
{
   public final String command;
   public final ParameterSyntax[] parameters;

   /**
    * Loot gold coins
    */
   public final static CommandSyntax clean              = CommandSyntax.make("clean");

   /**
    * Add citizen from residential building
    */
   public final static CommandSyntax pick               = CommandSyntax.make("pick");
   public final static CommandSyntax make               = CommandSyntax.make("make user_id klass x y rotation");
   public final static CommandSyntax create             = CommandSyntax.make("make user_id klass x y rotation");

   /**
    * Buy gift, (material from class 'klass') for friend 'second_user_id'
    */
   public final static CommandSyntax gift_from_shop     = CommandSyntax.make("gift_from_shop user_id klass second_user_id");

   public final static CommandSyntax quest_complete     = CommandSyntax.make("quest_complete quest_id");
   public final static CommandSyntax quest_list_accept  = CommandSyntax.make("quest_list_accept ids");
   public final static CommandSyntax quest_inc_counter  = CommandSyntax.make("quest_inc_counter");
   public final static CommandSyntax say_thanks         = CommandSyntax.make("say_thanks friend_id");
   public final static CommandSyntax send_gift          = CommandSyntax.make("send_gift item_id type_id room_id second_user_id");
   public final static CommandSyntax give_invite_window_bonus = CommandSyntax.make("give_invite_window_bonus");
   public final static CommandSyntax send_request       = CommandSyntax.make("send_request name friend_id");

   public static String request_name_invite_suggested_neighbors = "invite_suggested_neighbors";
   public static String request_name_share_badge_pick_contract2 = "share_badge_pick_contract2";

    public final static CommandSyntax commit_request       = CommandSyntax.make("commit_request name friend_id");


   public static String commit_request_name_visit_grand_season_opening = "visit_grand_season_opening";

   public final static CommandSyntax tick               = CommandSyntax.make("tick");
   public final static CommandSyntax confirm_friends_ids = CommandSyntax.make("confirm_friends_ids");

   public final static CommandSyntax mass_quest_inc_counter = CommandSyntax.make("mass_quest_inc_counter");

   /**
    * Help recover contract
    */
   public final static CommandSyntax help = CommandSyntax.make("help");

   public final static CommandSyntax apply_gift = CommandSyntax.make("apply_gift room_id item_id klass sender_user_id user_id");

   public final static CommandSyntax apply_help = CommandSyntax.make("apply_help room_id item_id friend_id user_id");

   public final static CommandSyntax suggest_neighbors = CommandSyntax.make("suggest_neighbors money only_head suggestions");

   public final static CommandSyntax quest_accept = CommandSyntax.make("quest_accept quest_id");

   public final static CommandSyntax pick_bus = CommandSyntax.make("pick_bus room_id item_id object_id");

   public final static CommandSyntax send_bus = CommandSyntax.make("send_bus room_id item_id object_id");

   /**
    * Move gift to store-house
     */
   public final static CommandSyntax barn_gift = CommandSyntax.make("barn_gift sender_user_id item_id klass");

   /**
    * Move item to new location on map
    */
   public final static CommandSyntax move = CommandSyntax.make("move room_id item_id rotation x y");

   public final static CommandSyntax set_quest_order = CommandSyntax.make("set_quest_order "); // ToDo

   /**
    * data is JSON object
    */
   public final static CommandSyntax mass_send_request = CommandSyntax.make("mass_send_request room_id data"); // ToDo

   /**
    * addMaterial / buy for friends
    * ToDo: check if working
    */
   public final static CommandSyntax apply_to_friend = CommandSyntax.make("apply_to_friend room_id  owner_id friend_id klass item_id");

   public final static String airport_mail = "airport_mail";

   /**
    * Start execute a contract (klass is contract klass)
    */
   public final static CommandSyntax put = CommandSyntax.make("put item_id klass");

   public final static CommandSyntax apply_item_from_barn = CommandSyntax.make("apply_item_from_barn");

   public final static CommandSyntax remove_from_wish_list = CommandSyntax.make("remove_from_wish_list");

   /**
    * Place barm item item_id to position x,y using rotation rotation
    */
   public final static CommandSyntax receive_item_from_barn = CommandSyntax.make("receive_item_from_barn room_id item_id rotation x y");

   /**
    * Buy material from trough sales pop-up
    * cached[0][command]	buy_sales_action
    * cached[0][room_id]	0
    * cached[0][sale_id]	sale_items_festiv
    * ached[0][items]	7
    * cached[0][item_ids]
    */
   public final static CommandSyntax buy_sales_action = CommandSyntax.make("buy_sales_action sale_id items item_ids");

   /**
    * Increase experience level
    */
   public final static CommandSyntax level_up = CommandSyntax.make("level_up room_id");

   public CommandSyntax(String command, ParameterSyntax[] parameters)
   {
      this.command = command;
      this.parameters = parameters;
   }

   public static CommandSyntax make(String syntax)
   {
      String[] word = syntax.split(" ");
      String command = word[0];
      ParameterSyntax[] params = new ParameterSyntax[word.length -1];
      for(int n=1;n<word.length;++n)
      {
         params[n-1] = ParameterSyntax.create(word[n]);
      }
      return new CommandSyntax(word[0], params);
   }

   @Override
   public String toString()
   {
      String line = this.command;
      for(ParameterSyntax ps : this.parameters)
      {
         line += " " + ps.toString();
      }
      return line;
   }
}

package rodinia.megapolis.api.command;

/**
 * Represents a SQ command parameter, may become smarter in the future: e.g. string and int types, items, user-id's etc...
 * Created by Rodinia on 20-8-2014.
 */
public class ParameterSyntax
{
   private final String name;

   public ParameterSyntax(String name)
   {
      this.name = name;
   }

   public static ParameterSyntax create(String paramSytax)
   {
      // ToDo: parse syntax
      return new ParameterSyntax(paramSytax);
   }

   @Override
   public String toString()
   {
      return name;
   }
}

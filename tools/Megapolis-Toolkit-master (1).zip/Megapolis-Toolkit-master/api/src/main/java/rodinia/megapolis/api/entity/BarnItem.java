package rodinia.megapolis.api.entity;

import rodinia.megapolis.api.entity.adapter.VariableTagNameAdapter;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * Created by Rodinia on 24-8-2014.
 */
@XmlJavaTypeAdapter(VariableTagNameAdapter.BarnItemAdapter.class)
public class BarnItem extends VariableTagNameItem
{
   @XmlAttribute(name="quantity")
   public int quantity;

   @XmlAttribute(name="updated_at")
   public int updated_at;

   public String toString()
   {
      return this.quantity + "x'" + this.name + "'";
   }
}

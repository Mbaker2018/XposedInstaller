package rodinia.megapolis.api.entity;

import rodinia.megapolis.api.entity.adapter.VariableTagNameAdapter;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * Can be used to download YAML files from SQ
 * Created by Rodinia on 21-8-2014.
 */

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.Instant;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@XmlJavaTypeAdapter(VariableTagNameAdapter.CityItemAdapter.class)
public class CityItem extends VariableTagNameItem
{
   private final static Set<String> ResidentialSet = makeResidentialSet();
   private final static Set<String> ProductionSet = makeProductionSet();

   public final static String name_bus_station_new_buildsite = "bus_station_new_buildsite";

   //private final static String[] infraSet ={"small_office_building_real_new_art"};

   private static Set<String> makeResidentialSet()
   {
      final String[] residentialSet ={"log_hut_tutorial", "small_japan_house", "bungalow_new_art", "business_class_residential_building", "house_steplherst", "bungalow_siena", "house_echo_art_real_dgift", "brick_house_new_art", "blue_bungalow", "blue_cottage", "cottage_albion_new_art_real", "curve_house_new", "mansion_new", "business_class_residential_building", "hotel_turtagro_new_real", "astro_train_center_real"};
      Set<String> set = new HashSet<String>();
      Collections.addAll(set, residentialSet);
      return set;
   }

   public final static String assemblyLine = "conveyor_new";
   public final static String carDealerShip = "car_center_factory_real";
   public final static String experimentalEnergyLab = "factory_research_center_real_new";
   public final static String experimentalGreenHouse = "factory_farm_new";
   public final static String householdGoodsFacility = "blamco_inc_new_art";
   public final static String householdGoodsStore = "machine_shop_new_art";
   public final static String mountain_hotel_stage1 = "mountain_hotel_stage1";

   public final static String airport_plane1_buildsite = "airport_plane1_buildsite";
   public final static String airport_plane6_buildsite = "airport_plane6_buildsite";
   public final static String airport_runway_stage1 = "airport_runway_stage1";

   /**
    * ToDo: This information should be dynamically being read from city_items.bin
    * @see rodinia.megapolis.api.CityAssets
    * @return
    */
   private static Set<String> makeProductionSet()
   {
      final String[] car_center_factory_real = {
              assemblyLine,
              carDealerShip,
              experimentalGreenHouse,
              experimentalEnergyLab,
              householdGoodsFacility,
              householdGoodsStore,
              "analysis_of_demographics",
              "experimental_energy_lab",
              "experimental_energy_lab_real",
              "fountain_of_youth_final",
              "holidays_agency_stage1",
              "mountain_hotel_stage1",
              "mountain_hotel_stage2",
              "meeting_of_producers",
              "times_square_stage1",
              "times_square_stage2",
              "youth_welfare_center_stage1",
              "youth_welfare_center_stage2",
              "youth_welfare_center_stage3",
      };
      Set<String> set = new HashSet<String>();
      Collections.addAll(set, car_center_factory_real);
      return set;
   }

   public boolean isResidential()
   {
      return ResidentialSet.contains(this.name) || this.name.contains("house") || this.name.contains("cottage") || this.name.contains("residential_complex");
   }

   public boolean isProduction()
   {
      return ProductionSet.contains(this.name);
   }

   //public String name;

   @XmlAttribute(name = "x")
   public int x;

   @XmlAttribute(name = "y")
   public int y;

   @XmlAttribute(name = "output_fill")
   public Integer output_fill;

   @XmlAttribute(name = "state")
   public int state;

   public final static int state_constructing= 1;
   public final static int state_idle = 2;
   public final static int state_busy = 3;
   public final static int state_contract_completed = 4;
   public final static int state_gold_completed = 5;

   /**
    * Contract expired
    */
   public final static int state_contract_expired = 6;

   public String getStateAsString()
   {
      switch(this.state)
      {
         case state_idle: return "idle";
         case state_busy: return "busy";
         case state_gold_completed: return "gold-completed";
         case state_contract_completed: return "contract-completed";
         case state_contract_expired: return "contract-expired";
         default: return Integer.toString(state);
      }
   }

   @XmlAttribute(name = "created_at")
   public int created_at;

   public Instant getCreatedAt()
   {
      return Instant.ofEpochMilli((long) created_at * 1000);
   }

   @XmlAttribute(name = "rotation")
   Boolean rotation;

   @XmlAttribute(name = "man_hour")
   String man_hour;

   @XmlAttribute(name = "process_end")
   public Integer process_end;

   @Override
   public String toString()
   {
      return "name=" + this.name + " id=" + this.id + " state=" + getStateAsString();// + " contract=" + (contract_input!=null ? "y" : "n");
   }

   @XmlAttribute(name = "contract_input")
   public Integer contract_input;

   public boolean isSubwayTrain()
   {
      return name.startsWith("subway_train_") && name.endsWith("_buildsite");
   }


}

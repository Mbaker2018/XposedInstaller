package rodinia.megapolis.api.entity;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * Created by Rodinia on 21-8-2014.
 */
public class CommandError
{
   @XmlAttribute(name = "command")
   public int command;

   @XmlAttribute(name = "params")
   public String params;
}

package rodinia.megapolis.api.entity;

/**
 * Created by Rodinia on 26-8-2014.
 */
public final class Contract
{
   public final static String train_subway_rush_hour1 = "subway_rush_hour1";
   public final static String contract_train_subway_weekday1 = "subway_weekday1";
   // contracts for factory_research_center_real_new:
   public final static String alternative_power_sources = "alternative_power_sources";
   public final static String bikes = "bikes";
   // contracts for factory_farm_new
   public final static String square_watermelons = "square_watermelons";
   // contracts car_center_factory_real
   public final static String sport_cars = "sport_cars";
   public final static String notebooks = "notebooks";
   public final static String grain_coffee = "grain_coffee";
   // mountain_hotel_stage1
   public final static String horse_sled_dogs = "horse_sled_dogs";

   // airport_plane6_buildsite:
   public final static String airport_mail = "airport_mail";
   public final static String airport_parachuting = "airport_parachuting";
}

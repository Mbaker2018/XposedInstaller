package rodinia.megapolis.api.entity;

import com.fasterxml.jackson.databind.ObjectMapper;

import rodinia.megapolis.api.entity.json.BusInformation;
import rodinia.megapolis.api.entity.json.ChestAction;
import rodinia.megapolis.api.entity.json.RoomInformation;

import javax.xml.bind.annotation.*;
import java.io.IOException;
import java.util.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="country")
public class Country
{
   public final static int room_megapolis = 0;
   public final static int room_rockies = 5;
   @XmlAttribute(name = "owner_id")
   public long owner_id;

   @XmlAttribute(name = "room_id")
   public int room_id;

   @XmlAttribute(name = "level")
   public int level;

   @XmlAttribute(name = "exp")
   public int experience;

   @XmlAttribute(name = "current_level_exp")
   public int current_level_exp;

   @XmlAttribute(name = "next_level_exp")
   public int next_level_exp;

   @XmlAttribute(name = "gold")
   public int gold;

   @XmlAttribute(name = "coins")
   public int coins;

   @XmlAttribute(name = "spent_coins")
   public int spent_coins;

   @XmlAttribute(name = "respect")
   public int respect;

   @XmlAttribute(name = "respect_level")
   public int respect_level;

   @XmlAttribute(name = "population")
   public int population;

   /**
    * Return the available population growth
    * @return available population growth
    */
   public int getAvailablePopulation()
   {
      return this.max_population - (this.population + 20000); // ToDo: No idea why the actual population is higher then this number
   }

   @XmlAttribute(name = "max_population")
   public int max_population;

   @XmlAttribute(name = "request_reward_count")
   public int request_reward_count;

   @XmlAttribute(name = "next_limited_request")
   public int next_limited_request;

   @XmlAttribute(name = "auto_enabled")
   public boolean auto_enabled;

   @XmlAttribute(name = "quest_flag")
   public int quest_flag;

   @XmlAttribute(name="version")
   public String version;

   @XmlAttribute(name="adv_counter")
   public int adv_counter;

   @XmlAttribute(name="roll_counter")
   public int roll_counter;

   @XmlAttribute(name="session_key")
   public String session_key;

   @XmlAttribute(name="server_time")
   public int server_time;

   @XmlAttribute(name="left_to_end_of_day")
   public int left_to_end_of_day;

   /**
    * JSON, e.g.:
    * {"rooms":{"room_5":{"available":true,"size_x":11,"size_y":11,"max_population":95025,"population":73040,"tax":15},"room_0":{"available":true,"size_x":21,"size_y":21}}}
    */
   @XmlAttribute(name="room_information")
   public String room_information;

   public RoomInformation getRoomInformation() throws IOException
   {
      return new ObjectMapper().readValue(this.room_information, RoomInformation.class);
   }

   @XmlAttribute(name="is_payer")
   public Boolean is_payer;

   @XmlAttribute(name="last_payment_date")
   public int last_payment_date;

   @XmlAttribute(name="next_gifts_time")
   public int next_gifts_time;

   @XmlAttribute(name="kakao")
   public String kakao;

   @XmlAttribute(name="wish_list")
   public String wish_list;

   public int[] getWishList()
   {
      if(wish_list != null)
      {
         String items[] = wish_list.split(",");
         int[] res = new int[items.length];
         for(int n=0 ;n<items.length;n++)
         {
            res[n] = Integer.parseInt(items[n]);
         }
         return res;
      }
      return new int[]{};
   }

   @XmlAttribute(name="shed")
   public String shed;

   /**
    * ToDo: JSON
    */
   @XmlAttribute(name="staff")
   public String staff;

   /**
    * ToDo: JSON
    */
   @XmlAttribute(name="staff_all")
   public String staff_all;

   /**
    * ToDo: JSON
    */
   @XmlAttribute(name="buses2")
   public String buses2;

   public BusInformation getBusInformation() throws IOException
   {
      return  buses2 == null || buses2.isEmpty() ? null : new ObjectMapper().readValue(this.buses2, BusInformation.class);
   }

   @XmlAttribute(name="visitors")
   public String visitors;

   @XmlAttribute(name="accelerated_items")
   public String accelerated_items;

   @XmlAttribute(name="buff_items")
   public String buff_items;

   @XmlAttribute(name="unlocked_items")
   public String unlocked_items;

   @XmlAttribute(name="resource_options")
   public String resource_options;

   @XmlAttribute(name = "imaginary_friend_name")
   public String imaginary_friend_name;

   @XmlAttribute(name = "city_name")
   public String city_name;

   @XmlElementWrapper(name="friends")
   @XmlElement(name="friend")
   public List<Friend>friends;

   @XmlElement(name="gifts")
   public Gifts gifts;

   @XmlElement(name="neighbors")
   public Neighbors neighbor;

   @XmlElementWrapper(name="quests")
   @XmlElement(name="quest")
   public List<Quest> quests;

   @XmlElementWrapper(name="field")
   @XmlAnyElement(lax=true)
   public List<CityItem>fields;

   @XmlElementWrapper(name="barn")
   @XmlAnyElement(lax=true)
   public List<BarnItem>barn;

   @XmlElement(name="sqbar")
   public String sqbar;

   @XmlElement(name="error")
   public CommandError error;

   /**
    * JSON
    * example: {'unlock_reward':{},'can_start':false,'duration':-1408707145000,'version':5}
    */
   @XmlElement(name="chest")
   public String chest ="{'unlock_reward':{},'can_start':false,'duration':-1408707145000,'version':5}";

   /**
    * JSON
    * example: {'chest_event7':{'v':1}}
    */
   @XmlElement(name="chest_actions")
   public String chest_actions;

   public Map<String, ChestAction> getChestActions() throws IOException
   {
      return chest_actions == null ? Collections.emptyMap() : new ObjectMapper().readValue(this.chest_actions, TreeMap.class);
   }

   @XmlElementWrapper(name="messages")
   @XmlElement(name="message")
   public List<Message>messages;

   // ToDo:
   //friend_achievements

   @XmlElement(name="ok")
   public String ok;

   public boolean isOk()
   {
      return this.ok != null;
   }

   @XmlAnyElement(lax=true)
   public List<org.w3c.dom.Element> others;

   public String getRoomName()
   {
      switch(this.room_id)
      {
         case 0: return "Megapolis";
         case 5: return "Rocky Mountains";
         default: return "room_id=" + this.room_id;
      }
   }

   @Override
   public String toString()
   {
     return "city_name=" + city_name + " room=" + this.getRoomName() + " owner=" + this.owner_id  + " " +
             "level=" + this.level + " coins=" + this.coins + " gold=" + this.gold + " experience=" + this.experience;
   }
}

package rodinia.megapolis.api.entity;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import rodinia.megapolis.api.entity.json.FriendRequest;
import rodinia.megapolis.api.entity.json.RoomInformation;

import javax.xml.bind.annotation.XmlAttribute;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Rodinia on 21-8-2014.
 */
public class Friend
{
   /**
    * Artificial player / friend
    */
   public final static int Alice = -41;

   /**
    * Artificial player / friend
    */
   public final static int Edward = -42;

   /**
    * Artificial player / friend
    */
   public final static int Mike = -43;

   @XmlAttribute(name = "id")
   public long id;

   @XmlAttribute(name = "level")
   public int level;

   @XmlAttribute(name = "is_payer")
   public boolean is_payer;

   @XmlAttribute(name = "next_visit_time_end")
   public int next_visit_time_end;

   @XmlAttribute(name = "have_gift")
   public boolean have_gift;

   @XmlAttribute(name = "help_points")
   public int help_points;

   /**
    * Return true if player is: Alice, Mike or Edward
    * @return true if player is Alice, Mike or Edward, otherwise false
    */
   public boolean isBot()
   {
      return this.id == Friend.Alice || this.id == Friend.Mike || this.id == Friend.Edward;
   }

   public class HelpItem
   {
      public int item_id;
      public int count;

      public HelpItem(int item_id, int count)
      {
         this.item_id = item_id;
         this.count = count;
      }
   }

   @XmlAttribute(name = "help_items")
   public String help_items;

   public List<HelpItem> getHelpItems()
   {
      LinkedList<HelpItem> list = new LinkedList<HelpItem>();
      if(help_items != null && !help_items.isEmpty())
      {
         String[] items = help_items.split(",");
         for (String word : items)
         {
            String item[] = word.split(":");
            list.add(new HelpItem(Integer.parseInt(item[0]), Integer.parseInt(item[1])));
         }
      }
      return list;
   }

   @XmlAttribute(name = "buddy_pending")
   public boolean buddy_pending;

   @XmlAttribute(name = "have_bus_station")
   public boolean have_bus_station = false;

   @XmlAttribute(name = "active")
   public boolean active;

   @XmlAttribute(name = "exp")
   public int exp;

   @XmlAttribute(name = "population")
   public int population;

   @XmlAttribute(name = "max_population")
   public int max_population;

   @XmlAttribute(name = "respect_level")
   public int respect_level;

   @XmlAttribute(name = "country_name")
   public String country_name;

   @XmlAttribute(name = "bus_region")
   public String bus_region;

   @XmlAttribute(name = "first_name")
   public String first_name;

   @XmlAttribute(name = "is_neighbor")
   public boolean is_neighbor;

   @XmlAttribute(name = "friends_top_score")
   public int friends_top_score;

   @XmlAttribute(name = "city_name")
   public String city_name;

   @XmlAttribute(name = "last_platform")
   public String last_platform;

   @XmlAttribute(name = "wish_list")
   public String wish_list;

   public int[] getWishList()
   {
      if(wish_list != null && !wish_list.isEmpty())
      {
         String items[] = wish_list.split(",");
         int[] res = new int[items.length];
         for(int n=0 ;n<items.length;n++)
         {
            res[n] = Integer.parseInt(items[n]);
         }
         return res;
      }
      return new int[]{};
   }

   @XmlAttribute(name = "requests")
   public String requests; // ToDo: JSON parsing

   public Map<String, FriendRequest> getRequests() throws IOException
   {
      JavaType returnType = TypeFactory.defaultInstance().constructParametricType(Map.class, String.class, FriendRequest.class);
      return requests == null ? new TreeMap<String, FriendRequest>() : (Map<String, FriendRequest>) new ObjectMapper().readValue(this.requests,  returnType);
   }

   /**
    * JSON
    */
   @XmlAttribute(name = "owner_room_info")
   public String owner_room_info;

   public RoomInformation getOwnerRoomInformation() throws IOException
   {
      return new ObjectMapper().readValue(this.owner_room_info, RoomInformation.class);
   }

   public String getPlayerName()
   {
      return this.city_name != null ? this.city_name : this.first_name;
   }

   @Override
   public String toString()
   {
      String result = "";
      if(this.first_name != null)
      {
         result += "player=" + this.first_name;
      }
      if(this.city_name != null)
      {
         if(!result.isEmpty())
            result += " ";
         result += "city=" + this.city_name;
      }
      return result;
   }


}

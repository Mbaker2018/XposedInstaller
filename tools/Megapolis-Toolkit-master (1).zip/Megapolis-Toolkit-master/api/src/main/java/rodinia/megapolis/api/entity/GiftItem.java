package rodinia.megapolis.api.entity;

import rodinia.megapolis.api.entity.adapter.VariableTagNameAdapter;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * Created by Rodinia on 22-8-2014.
 */
@XmlJavaTypeAdapter(VariableTagNameAdapter.GiftItemAdapter.class)
public class GiftItem extends VariableTagNameItem
{
}

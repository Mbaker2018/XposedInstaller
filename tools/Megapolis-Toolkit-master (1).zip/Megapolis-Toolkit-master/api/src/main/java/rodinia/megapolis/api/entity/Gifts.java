package rodinia.megapolis.api.entity;

import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name="gifts")
public class Gifts
{
   @XmlElementWrapper(name="received")
   @XmlAnyElement(lax=true)
   public List<ReceivedGiftItem> receivedGifts;

   @XmlElementWrapper(name="available")
   @XmlAnyElement(lax=true)
   public List<GiftItem> availableGifts;
}

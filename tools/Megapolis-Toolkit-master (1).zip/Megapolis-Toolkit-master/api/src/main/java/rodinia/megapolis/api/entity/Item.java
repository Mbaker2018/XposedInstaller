package rodinia.megapolis.api.entity;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * Created by Rodinia on 24-8-2014.
 */
public class Item
{
   @XmlAttribute(name = "id")
   public int id;

}

package rodinia.megapolis.api.entity;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * Created by Rodinia on 21-8-2014.
 */
public class Message
{
   @XmlAttribute(name = "raw_text")
   public String raw_text;

   @XmlAttribute(name = "text")
   public String text;
}

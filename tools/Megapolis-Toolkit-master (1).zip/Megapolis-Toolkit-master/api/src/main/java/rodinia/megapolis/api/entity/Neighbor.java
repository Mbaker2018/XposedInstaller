package rodinia.megapolis.api.entity;

/**
 * Created by Rodinia on 21-8-2014.
 */
public class Neighbor
{
}

package rodinia.megapolis.api.entity;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import java.time.Instant;
import java.util.List;

/**
 * Created by Rodinia on 21-8-2014.
 */
public class Neighbors
{
   @XmlAttribute(name=" max_neighbors")
   int max_neighbors;

   @XmlAttribute(name="last_suggest_neighbors_date")
   int last_suggest_neighbors_date;

   public Instant getLastSuggestNeighborsDate()
   {
      return Instant.ofEpochMilli((long)this.last_suggest_neighbors_date * 1000L);
   }

   @XmlElement(name="neighbor")
   public List<Neighbor> neighbors;

   @XmlElementWrapper(name="new_neighbors")
   @XmlElement(name="friend")
   public List<Friend> new_neighbors;
}

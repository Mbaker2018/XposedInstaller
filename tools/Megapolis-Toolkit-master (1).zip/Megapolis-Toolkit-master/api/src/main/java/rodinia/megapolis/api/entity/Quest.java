package rodinia.megapolis.api.entity;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by Rodinia on 21-8-2014.
 */
@XmlRootElement(name="quest")
public class Quest
{
   @XmlAttribute(name = "id")
   public int id;

   @XmlAttribute(name = "order")
   public int order;

   @XmlAttribute(name = "started_at")
   public int started_at;

   @XmlAttribute(name = "counters")
   public String counters;

   @XmlAttribute(name = "completed")
   public boolean completed;
}

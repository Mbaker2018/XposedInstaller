package rodinia.megapolis.api.entity;



import rodinia.megapolis.api.entity.adapter.VariableTagNameAdapter;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * Created by Rodinia on 22-8-2014.
 */
@XmlJavaTypeAdapter(VariableTagNameAdapter.ReceivedGiftItemAdapter.class)
public class ReceivedGiftItem extends GiftItem
{
   @XmlAttribute(name = "from_user_id")
   public long from_user_id;

   @XmlAttribute(name = "created_at")
   public long created_at;

   @XmlAttribute(name = "quantity")
   public int quantity;
}

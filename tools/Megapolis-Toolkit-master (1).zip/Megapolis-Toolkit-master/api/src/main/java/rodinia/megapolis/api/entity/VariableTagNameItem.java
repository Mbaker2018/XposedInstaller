package rodinia.megapolis.api.entity;

/**
 * Created by Rodinia on 22-8-2014.
 */
public class VariableTagNameItem extends Item
{
   /**
    * Element name
    */
   public String name;
}

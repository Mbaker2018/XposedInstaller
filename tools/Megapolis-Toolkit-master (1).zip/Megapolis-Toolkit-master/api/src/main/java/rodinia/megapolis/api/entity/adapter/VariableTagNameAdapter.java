package rodinia.megapolis.api.entity.adapter;

import rodinia.megapolis.api.entity.*;
import org.w3c.dom.Element;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.transform.dom.DOMSource;

/**
 * Created by Rodinia on 21-8-2014.
 */
public class VariableTagNameAdapter<BoundType extends VariableTagNameItem> extends XmlAdapter<Element, BoundType>
{
   private JAXBContext jaxbContext;
   private Class<?> boundType;

   public VariableTagNameAdapter(Class<BoundType> boundType)
   {
      this.boundType = boundType;
   }

   public VariableTagNameAdapter(JAXBContext jaxbContext)
   {
      this.jaxbContext = jaxbContext;
   }

   @Override
   public Element marshal(BoundType item) throws Exception
   {
      throw new NotImplementedException();
   }

   @Override
   public BoundType unmarshal(Element element) throws Exception
   {
      if (null == element)
      {
         return null;
      }
      // 1. Determine the values type from the type attribute.

      // 2. Unmarshal the element based on the value's type.
      DOMSource source = new DOMSource(element);

      Unmarshaller unmarshaller = getJAXBContext(this.boundType).createUnmarshaller();
      JAXBElement jaxbElement = unmarshaller.unmarshal(source,  this.boundType);

      // 3. Build the instance of Parameter
      BoundType fieldItem = (BoundType) jaxbElement.getValue();
      fieldItem.name = element.getLocalName();
      return fieldItem;
   }

   private JAXBContext getJAXBContext(Class<?> type) throws Exception
   {
      if (null == jaxbContext)
      {
         // A JAXBContext was not set, so make a new one based  on the type.
         return JAXBContext.newInstance(type);
      }
      return jaxbContext;
   }

  public static class BarnItemAdapter extends VariableTagNameAdapter<BarnItem>
   {
      public BarnItemAdapter()
      {
         super(BarnItem.class);
      }
   }

   public static class GiftItemAdapter extends VariableTagNameAdapter<GiftItem>
   {
      public GiftItemAdapter()
      {
         super(GiftItem.class);
      }
   }

   public static class CityItemAdapter extends VariableTagNameAdapter<CityItem>
   {
      public CityItemAdapter()
      {
         super(CityItem.class);
      }
   }

   public static class ReceivedGiftItemAdapter extends VariableTagNameAdapter<ReceivedGiftItem>
   {
      public ReceivedGiftItemAdapter()
      {
         super(ReceivedGiftItem.class);
      }
   }
}

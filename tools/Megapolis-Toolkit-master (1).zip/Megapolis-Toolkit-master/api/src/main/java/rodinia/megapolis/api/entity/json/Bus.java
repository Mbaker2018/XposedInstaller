package rodinia.megapolis.api.entity.json;

import java.util.List;

/**
* Created by Rodinia on 22-8-2014.
*/
public class Bus
{
   public final static int state_Idle = 0;
   public final static int state_Busy = 1;
   public final static int state_Completed = 2;

   /**
    * Not the same as the object_id
    */
   public int item_id;

   /**
    * 2 = completed?
    */
   public int state;

   public List<BusRoute> route;

   public int race;

   public int total_race;

   public int total_coins;

   public int total_population;

   public int total_time;

   public Integer process_end;
}

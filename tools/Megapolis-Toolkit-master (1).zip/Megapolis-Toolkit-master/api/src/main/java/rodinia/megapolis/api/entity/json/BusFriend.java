package rodinia.megapolis.api.entity.json;

/**
 * Created by Rodinia on 22-8-2014.
 */
public class BusFriend
{
   public int expire_end;
}

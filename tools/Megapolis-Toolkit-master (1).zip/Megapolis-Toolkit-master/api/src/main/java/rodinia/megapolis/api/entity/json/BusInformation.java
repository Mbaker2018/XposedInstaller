package rodinia.megapolis.api.entity.json;

import java.util.Map;

/**
 * Created by Rodinia on 22-8-2014.
 */
public class BusInformation
{
   public int id_seq;

   public Map<Integer, BusStation> items;

   public Map<Long, BusFriend> friends;

}

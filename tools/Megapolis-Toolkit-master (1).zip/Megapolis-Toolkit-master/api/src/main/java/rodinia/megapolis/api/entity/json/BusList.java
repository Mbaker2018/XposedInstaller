package rodinia.megapolis.api.entity.json;

import java.util.Map;

/**
* Created by Rodinia on 22-8-2014.
*/
public class BusList
{
   public int item_id;

   /**
    * Key = bus object_id
    */
   public Map<Integer, Bus> list;
}

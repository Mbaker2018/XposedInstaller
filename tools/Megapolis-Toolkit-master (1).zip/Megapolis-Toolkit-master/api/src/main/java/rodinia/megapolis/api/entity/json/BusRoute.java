package rodinia.megapolis.api.entity.json;

/**
* Created by Rodinia on 22-8-2014.
*/
public class BusRoute
{
   /**
    * Player ID
    */
   public long id;

   public int state;

   public int distance;
}

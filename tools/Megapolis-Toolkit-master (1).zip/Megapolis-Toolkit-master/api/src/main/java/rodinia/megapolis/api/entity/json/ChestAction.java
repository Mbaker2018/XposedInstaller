package rodinia.megapolis.api.entity.json;

import java.util.Map;

/**
 * Created by Rodinia on 22-8-2014.
 */
public class ChestAction
{
   public Map<String, Room> rooms;
}

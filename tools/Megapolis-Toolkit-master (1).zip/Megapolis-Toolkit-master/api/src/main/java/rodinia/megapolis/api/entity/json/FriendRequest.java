package rodinia.megapolis.api.entity.json;

import java.util.List;

/**
 * Created by Rodinia on 22-8-2014.
 */
public class FriendRequest
{
   public long time;
   public int pushed;
   public int count;

   public Integer commit_count;
   public List<Long> user;
   public List<Transport> transport;
   public List<Integer> st_items;
   public Integer item_id;
   public Integer room_id;
   public Integer contract_id;
   public Integer object_id;
}

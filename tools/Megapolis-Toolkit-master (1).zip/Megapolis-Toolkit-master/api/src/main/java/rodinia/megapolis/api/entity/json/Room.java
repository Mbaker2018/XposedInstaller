package rodinia.megapolis.api.entity.json;

/**
 * Created by Rodinia on 22-8-2014.
 */
public class Room
{
   public boolean available;
   public int size_x;
   public int size_y;

   public Integer max_population;
   public Integer population;
   public Integer tax;

   public Integer size_x_2;
   public Integer size_y_2;

   public Integer size_x_3;
   public Integer size_y_3;

   public Integer size_x_4;
   public Integer size_y_4;

   public Integer size_x_5;
   public Integer size_y_5;

   public Integer size_x_6;
   public Integer size_y_6;

   public Integer size_x_7;
   public Integer size_y_7;

   public Integer size_x_8;
   public Integer size_y_8;

   public String shed;

   private final static String room_prefix = "room_";

   public static int getId(String roomKey)
   {
      if(roomKey != null && roomKey.startsWith(room_prefix))
      {
         return Integer.parseInt(roomKey.substring(room_prefix.length()));
      }
      throw new IllegalArgumentException("roomKey = " + roomKey);
   }
}

package rodinia.megapolis.api.entity.json;

/**
 * Created by Rodinia on 22-8-2014.
 */
public class Transport
{
   public int bus_id;
   public int item_id;
   public int distance;
   public int race;
   public int count;

   public Transport()
   {
   }

   public Transport(int bus_id, int item_id, int distance, int count)
   {
      this.bus_id = bus_id;
      this.item_id = item_id;
      this.distance = distance;
      this.distance = distance;
      this.count = 1;

   }
}

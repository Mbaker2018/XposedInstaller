package rodinia.megapolis.api.entity.json;

import rodinia.megapolis.api.IUserId;

import java.util.Map;

/**
 * Created by Rodinia on 23-8-2014.
 */
public class UserId implements IUserId
{
   /**
    * One of: user_created, ok
    */
   public String status;

   public long user_id;

   public String sq_sig;

   public Map<String, String> associations;

   public String toString()
   {
      return "user_id=" + this.user_id + " sq_sig=" + this.sq_sig;
   }

   @Override public long getId()
   {
      return this.user_id;
   }

   @Override public String getToken()
   {
      return this.sq_sig;
   }
}

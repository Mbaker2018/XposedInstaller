package rodinia.megapolis.api.request;

import rodinia.megapolis.api.UserProfile;
import rodinia.megapolis.api.command.Command;

import java.util.Collection;
import java.util.Locale;
import java.util.Map;

/**
 * Created by Rodinia on 18-8-2014.
 */
public class CachedCommandRequest extends UserRequest
{
   private final static String param_name_rn = "rn";
   private final static String param_rand = "rand";
   private final static String param_live_update = "live_update";
   private final static String param_serv_ver = "serv_ver";

   private int commandSeqNum = 0;
   private int uxTime;

   public CachedCommandRequest(UserProfile userProfile, int room_id)
   {
      super(userProfile, room_id);

      this.uxTime = CachedCommandRequest.getUxTime();

      this.param(param_serv_ver, "1");
      this.param(param_rand, CachedCommandRequest.getRand());
      this.param(param_live_update, "true");
   }

   public CachedCommandRequest(UserProfile userProfile, int room_id, Command... commands)
   {
      this(userProfile, room_id);
      this.add(commands);
   }

   public CachedCommandRequest(UserProfile userProfile, int room_id, Collection<Command> commands)
   {
      this(userProfile, room_id);
      this.add(commands);
   }

   public void add(Command... commands)
   {
      for(Command command : commands)
      {
         this.add(command);
      }
   }

   public void add(Collection<Command> commands)
   {
      for(Command command : commands)
      {
         this.add(command);
      }
   }

   public void add(Command command)
   {
      int cmdIndex = this.commandSeqNum++;
      this.param(makeCommandKey(cmdIndex, "command"), command.command);
      for (Map.Entry<String, String> argument : command.getArguments().entrySet())
      {
         this.param(makeCommandKey(cmdIndex, argument.getKey()), argument.getValue());
      }
      // Common command key/value's
      this.param(makeCommandKey(cmdIndex, "uxtime"), Integer.toString(this.uxTime));
   }

   private static String makeCommandKey(int index, String key)
   {
      return "cached[" + index + "][" + key + "]";
   }

   public static String getRand()
   {
      double random = Math.random();
      return String.format(Locale.US, "%.5g", random);
   }

   public static CachedCommandRequest make(UserProfile userProfile, int room_id, Command command)
   {
      return new CachedCommandRequest(userProfile, room_id, command);
   }

   public static int getUxTime()
   {
      return (int) (System.currentTimeMillis() / 1000);
   }
}

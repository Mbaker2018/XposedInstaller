package rodinia.megapolis.api.request;

import rodinia.megapolis.api.UserProfile;
import rodinia.megapolis.api.command.Command;

import java.util.Map;

/**
 * Used in combination with the http URL: process
 * Created by Borewit on 18-8-2014.
 */
public class CommandRequest extends UserRequest
{
   private final static String param_live_update = "live_update";
   private final static String param_serv_ver = "serv_ver";
   private final static String param_room_id = "room_id";

   public CommandRequest(UserProfile userProfile, int room_id, Command command)
   {
      super(userProfile, room_id);

      this.setCommand(command);
   }

   private void setCommand(Command command)
   {
      this.param("command", command.command);
      for (Map.Entry<String, String> argument : command.getArguments().entrySet())
      {
         this.param(argument.getKey(), argument.getValue());
      }

      //this.param(param_room_id, "0");
      this.param(param_serv_ver, "1");
      this.param(param_live_update, "true");
   }

   public static CommandRequest make(UserProfile userProfile, int room_id, Command command)
   {
      return new CommandRequest(userProfile, room_id, command);
   }

}

package rodinia.megapolis.api.request;

import javax.ws.rs.core.Form;

public class FindUserIdRequest extends Form
{
   public final static String param_revision = "revision";
   public final static String param_client_type = "client_type";
   public final static String param_first_request = "first_request";
   public final static String param_view_friend_id = "view_friend_id";

   public final static String param_no_create = "no_create";
   public final static String param_associate = "associate";
   public final static String param_platform = "platform";
   public final static String param_build = "build";
   public final static String param_app = "app";
   public final static String param_device_model = "device_model";
   public final static String param_os = "os";
   public final static String param_gloc = "gloc";
   public final static String param_dloc = "dloc";
   public final static String param_net = "net";
   public final static String param_odin_id = "odin_id";
   public final static String param_open_udid = "open_udid";
   public final static String param_mac = "mac";
   public final static String param_advertising_id = "advertising_id";

   // Apple IOS
   public final static String param_social_id_GC = "social_id[GC]";

   // Android:
   public final static String param_device_id = "device_id";
   public final static String param_android_imei = "android_imei";
   public final static String param_android_id = "android_id";

  public static FindUserIdRequest fromGameCenterId(long gameCenterId)
   {
      FindUserIdRequest req = new FindUserIdRequest();
      req.param(param_social_id_GC, "G:" + gameCenterId);
      req.param(param_no_create, "no");
      req.param(param_associate, "yes");

      return req;
   }
}

package rodinia.megapolis.api.request;

import rodinia.megapolis.api.IUserId;
import rodinia.megapolis.api.UserProfile;

import javax.ws.rs.core.Form;

/**
 * Created by Rodinia on 18-8-2014.
 */
public class UserRequest extends Form
{
   public final static String param_daily_gift = "daily_gift";

   /**
    * @see rodinia.megapolis.api.UserProfile.NetworkType
    */
   public final static String param_sq_token = "iauth";

   /**
    * @see rodinia.megapolis.api.UserProfile.NetworkType
    */
   public final static String param_facebook_token = "auth_key";

   public final static String param_userid = "user_id";
   public final static String param_room_id = "room_id";
   public final static String param_lang = "lang";

   public final static String english = "en";

   public UserRequest(UserProfile userProfile, int room_id)
   {
      this(userProfile.networkType, userProfile.getId(), userProfile.getToken(), room_id);
   }

   public UserRequest(IUserId userProfile, int room_id)
   {
      this(UserProfile.determineNetworkType(userProfile), userProfile.getId(), userProfile.getToken(), room_id);
   }

   public UserRequest(UserProfile.NetworkType networkType, IUserId userProfile, int room_id)
   {
      this(networkType, userProfile.getId(), userProfile.getToken(), room_id);
   }


   public UserRequest(UserProfile.NetworkType networkType, long userid, String token, int room_id)
   {
     this.param(param_userid, Long.toString(userid))
        .param(networkType == UserProfile.NetworkType.SocialQuantum ? param_sq_token : param_facebook_token, token)
        .param(param_room_id, Integer.toString(room_id))
        .param(param_daily_gift, "1")
        .param(param_lang, english);
   }



}

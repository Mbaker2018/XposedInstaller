package rodinia.megapolis.api.request;

import rodinia.megapolis.api.IUserId;
import rodinia.megapolis.api.UserProfile;

/**
 * Created by Rodinia on 18-8-2014.
 */
public class UserStatRequest extends UserRequest
{
   public final static String revision_value = "android-1.92.3197";
   public final static String client_type_value = "android";

   public final static String param_revision = "revision";
   public final static String param_client_type = "client_type";
   public final static String param_first_request = "first_request";
   public final static String param_view_friend_id = "view_friend_id";

   public UserStatRequest(IUserId userProfile, int room_id)
   {
      super(userProfile, room_id);
      this.param(param_revision, revision_value)
         .param(param_client_type, client_type_value)
         .param(param_first_request, "true");
   }

   public UserStatRequest(UserProfile userProfile, int room_id, long view_friend_id)
   {
      this(userProfile, room_id);
      this.param(param_view_friend_id, Long.toString(view_friend_id));
   }
}

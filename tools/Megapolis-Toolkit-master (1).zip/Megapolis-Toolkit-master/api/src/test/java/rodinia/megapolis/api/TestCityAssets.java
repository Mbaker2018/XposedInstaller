package rodinia.megapolis.api;


import junit.framework.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.Map;

/**
 * Created by Rodinia on 30-8-2014.
 */
public class TestCityAssets
{
   @Test
   public void download_city_options() throws IOException
   {
      Map<String, Object> map = CityAssets.getFileAsYamlMap(CityAssets.file_city_options);
      Assert.assertNotNull(map);
      Assert.assertFalse(map.isEmpty());
   }
}

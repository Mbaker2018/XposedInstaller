package rodinia.megapolis.api;

import junit.framework.Assert;
import org.junit.Before;
import rodinia.megapolis.api.entity.Country;
import rodinia.megapolis.api.entity.json.UserId;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by Rodinia on 23-8-2014.
 */
public class TestSocialQuantumClient
{
   private SocialQuantumClient sqc;

   /**
    * Apple Game Center Player ID
    */
   private final long AppleGameCenterPlayerId = 2512431898L;

   @Before
   public void init()
   {
      this.sqc = SocialQuantumClient.connectToRandomHost();
   }

   @Test
   public void lookupGameCenterId() throws IOException
   {
      // Login into Social Quantum with provided Apple ID
      final UserId userId = this.sqc.findUserIdByGameCenterId(AppleGameCenterPlayerId);

      // Check for valid Social Quantum User ID
      Assert.assertNotNull(userId);
      Assert.assertNotNull(userId.status);

      Country country = this.sqc.postUserStat(userId, Country.room_megapolis);
      Assert.assertNotNull(country);
   }
}

package rodinia.megapolis;

import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import rodinia.megapolis.api.SocialQuantumClient;
import rodinia.megapolis.api.UserProfile;
import rodinia.megapolis.api.command.Command;
import rodinia.megapolis.api.command.CommandFactory;
import rodinia.megapolis.api.entity.*;
import rodinia.megapolis.api.entity.json.*;
import org.w3c.dom.Element;


import java.io.IOException;
import java.util.*;

/**
 * Prototype showing that the Megapolis API can be used the automate the client
 * Created by Rodinia on 18-8-2014.
 */
public class MegapolisBot
{
   private final SocialQuantumClient client;

   private boolean helpFriends = true;
   private boolean queueCommands = true;
   private boolean printFields = false;
   private boolean skipBots = false;
   private boolean sendGiftsToFriends = true;
   private boolean startContracts = true;

   private long command_delay_ms = 0;

   public static void main(final String[] args) throws Exception
   {
      System.out.println("Starting Megapolis bot...");

      Long sqid = null;
      String sqtoken = null;

      for(final String arg : args)
      {
         if(arg.startsWith("sqid="))
         {
            sqid = Long.parseLong(arg.substring(5));
         }
         else if(arg.startsWith("sqtoken="))
         {
            sqtoken = arg.substring(8);
         }
      }

      if(sqid != null && sqtoken != null)
      {
         final SocialQuantumClient sqc = SocialQuantumClient.connectToRandomHost();
         UserProfile myProfile = new UserProfile(sqid.longValue(), sqtoken);
         System.out.println("Using profile: " + myProfile);

         MegapolisBot bot = new MegapolisBot(sqc);
         bot.maintainGame(myProfile, null); // ToDo
      }
      else
      {
         System.out.println("Specify user account: --sqid=<Social Quantum ID> --sqtoken=<Social Quantum Token>");
      }
   }

   public MegapolisBot(SocialQuantumClient sqc)
   {
      this.client = sqc;
   }

   public void maintainGame(UserProfile myProfile, final UserProfile[] userProfiles) throws IOException, InterruptedException
   {
      int maxAttempts = 5;
      int attempts = 0;
      do
      {
         try
         {
            System.out.println("Connecting to " + client.getUrl());
            Country country = client.postUserStat(myProfile, Country.room_megapolis);
            this.printCountry(country);
            System.out.println();
            this.maintainGame(myProfile, country, helpFriends, userProfiles);
            break;
         }
         catch(UnrecognizedPropertyException upe)
         {
            throw upe;
         }
         catch (IOException ioe)
         {
            ++attempts;
            System.err.println("Got I/O Exception on attempt #" + attempts + "/" + maxAttempts + " while connection to SQ ");
            System.err.println(ioe);
            this.client.changeHost();
         }
      }
      while(attempts < maxAttempts);
   }

   private void maintainGame(UserProfile myProfile, Country country, boolean helpFriends, final UserProfile[] userProfiles) throws IOException, InterruptedException
   {
      System.out.println("Do maintenance...");

      System.out.println("Do daily gift: daily");
      if(country.next_gifts_time <= 0)
      {

      }

      // Try to claim invite bonus from neighbour invitation
      // ToDo this.postCommand(myProfile, CommandFactory.give_invite_window_bonus());

      // Answer requests
      ArrayList<Command> commandQueue = new ArrayList<Command>();

      // Maintain busses
      System.out.println("  Maintain bus stations...");

      this.maintainBuses(myProfile, country);

      if (!commandQueue.isEmpty())
      {
         this.postCommand(myProfile, country.room_id, commandQueue);
         commandQueue.clear();
      }

      System.out.println("  Process received gifts...");
      if (country.gifts.availableGifts != null)
      {
         for (ReceivedGiftItem gift : country.gifts.receivedGifts)
         {
            System.out.println("    Barn gift to storehouse id=" + gift.id + " name=" + gift.name + " from=" + gift.from_user_id);
            this.postCommand(myProfile, country.room_id, CommandFactory.barn_gift(gift.id, gift.name, gift.from_user_id));
         }
      }

      System.out.println("  Process friends wish-lists...");

      final TreeMap<Integer, GiftItem> availableGifts = new TreeMap<Integer, GiftItem>();
      for(GiftItem gift : country.gifts.availableGifts)
      {
         availableGifts.put(gift.id, gift);
      }

      Collections.sort(country.friends, new PrioritizeFriends(userProfiles));

      // Process friend requests
      for (Friend friend : country.friends)
      {
         System.out.println("    Helping friend: "+ friend);
         friend.getWishList();

         if(this.sendGiftsToFriends)
         {
            System.out.println("      Examine wish list of friend: " + friend);
            for (int wish_item_id : friend.getWishList())
            {
               GiftItem gift = availableGifts.get(wish_item_id);
               if (gift != null)
               {
                  Command cmd = CommandFactory.send_gift(friend, gift.id);
                  System.out.println("     Send gift  #" + gift.id + " type=" + gift.name + " to: " + friend.toString());
                  commandQueue.add(cmd);
                  availableGifts.remove(gift.id);
               }
            }
            if (!commandQueue.isEmpty())
            {
               this.postCommand(myProfile, country.room_id, commandQueue);
               commandQueue.clear();
            }
         }

         System.out.println("      Examine help items of friend: "+ friend);
         for( Friend.HelpItem helpItem : friend.getHelpItems())
         {
            System.out.println("    Apply help from: [" + friend.toString() + "], om item: " + helpItem.item_id);
            Command cmd = CommandFactory.apply_help(friend, country.room_id, helpItem.item_id);
            commandQueue.add(cmd);
         }
         if(!commandQueue.isEmpty())
         {
            this.postCommand(myProfile, country.room_id, commandQueue);
            commandQueue.clear();
         }

         System.out.println("      Examine requests of friend: "+ friend);
         for (Map.Entry<String, FriendRequest> request : friend.getRequests().entrySet())
         {
            System.out.println("      Rx-request: from: " + friend.getPlayerName() + " subject: " + request.getKey());
            if(request.getValue().transport != null)
            {
               System.out.println("        Reply to transport request");
               //Command cmd = CommandFactory.commit_request(friend, request.getKey(), request.getValue().transport);
               Command cmd = CommandFactory.commit_request(friend, request.getValue().transport);
               commandQueue.add(cmd);
            }
            if(request.getValue().contract_id != null)
            {
               System.out.println("        Reply to contract request");
               Command cmd = CommandFactory.commit_request_contract(friend, request.getKey(), request.getValue().room_id, request.getValue().contract_id);
               commandQueue.add(cmd);
            }
            else
            {
               System.out.println("        Reply to common request");
               Command cmd = CommandFactory.commit_request(friend, request.getKey());
               commandQueue.add(cmd);
            }
         }

         try
         {
            if(!commandQueue.isEmpty())
            {
               this.postCommand(myProfile, country.room_id, commandQueue);
               commandQueue.clear();
            }
         }
         catch(Throwable e)
         {
            System.out.println("    Failed to process request: from: " + friend.getPlayerName());
         }

      }

      if(!country.friends.isEmpty())
      {
         final Friend bestFriend = country.friends.get(0);
         System.out.println("      Give remaing gifts to best friend: " + bestFriend);
         // Give last gifts away to most prefered user
         while (!availableGifts.isEmpty())
         {
            GiftItem gift = availableGifts.firstEntry().getValue();
            Command cmd = CommandFactory.send_gift(bestFriend, gift.id);
            System.out.println("     Send gift  #" + gift.id + " type=" + gift.name + " to: " + bestFriend.toString());
            commandQueue.add(cmd);
            availableGifts.remove(gift.id);
         }
         this.postCommand(myProfile, country.room_id, commandQueue);
         commandQueue.clear();
      }


      // Collect from City Items
      for(Map.Entry<String, Room> room : country.getRoomInformation().rooms.entrySet())
      {
         final int room_id = Room.getId(room.getKey());
         if(room.getValue().available)
         {
            System.out.println("    Collecting items for " + myProfile.userId + " in room #" + room_id);
            Country country_room = room_id == country.room_id ? country : client.postUserStat(myProfile, room_id);
            this.collect(myProfile, country_room);
         }
      }

      if (helpFriends && country.friends != null)
      {
         for (Friend friend : country.friends)
         {
            if(!skipBots || !friend.isBot())
            {
               this.helpFriendCountry(myProfile, friend);
            }
            else
            {
               System.out.println("    Skip Friend: id=" + friend.id + " name=" + friend.getPlayerName() + " level=" + friend.level);
            }
         }
      }
   }

   private void maintainBuses(final UserProfile myProfile, final Country country) throws IOException, InterruptedException
   {
      BusInformation busInformation = country.getBusInformation();
      if(busInformation != null)
      {
         for (Map.Entry<Integer, BusStation> busStationItem : busInformation.items.entrySet())
         {
            System.out.println("    Maintain bus station: " + busStationItem.getKey());
            for (Map.Entry<Integer, Bus> bus : busStationItem.getValue().list.entrySet())
            {
               System.out.println("      Maintain bus: " + bus.getKey() + " item_id=" + bus.getValue().item_id + " state=" + bus.getValue().state);
               switch (bus.getValue().state)
               {
                  case Bus.state_Completed:
                     // Pick bus:
                     this.postCommand(myProfile, country.room_id, (CommandFactory.pick_bus(country.room_id, busStationItem.getKey(), bus.getKey())));
                     // continue with sending bus

                  case Bus.state_Idle:
                     // Send bus:
                     try
                     {
                        this.postCommand(myProfile, country.room_id, (CommandFactory.send_bus(country.room_id, busStationItem.getKey(), bus.getKey())));
                     }
                     catch (Throwable throwable)
                     {
                        System.out.println("ERRROR:     Sending bus failed, might be something odd with its route.");
                     }
                     break;

                  case Bus.state_Busy:
                     break;

                  default:
                     System.out.println("   WARNING: Unknown bus state: " + bus.getValue().state);
               }
            }
         }
      }
   }

   private void collect(UserProfile myProfile, Country country) throws IOException, InterruptedException
   {
      System.out.println("Maintain own city: " + country.city_name + "/" + country.getRoomName());

      for (Map.Entry<String, ChestAction> chestAction : country.getChestActions().entrySet())
      {
         System.out.println("    Chest action: id=" + chestAction.getKey());
      }

      ArrayList<Command> commandQueue = new ArrayList<Command>();

      final Map<String, String> contractMap = makeAutoContractMap();

      for (CityItem fieldItem : country.fields)
      {
         // experimental_energy_lab_real

         switch (fieldItem.state)
         {
            case CityItem.state_idle: // Collect residents
            {
               if(fieldItem.isResidential())
               {
                  if(country.getAvailablePopulation() > fieldItem.output_fill)
                  {
                     System.out.println("Collect (pick): " + fieldItem);
                     final Command cmd_pick = CommandFactory.pick(country.room_id, fieldItem.id);
                     commandQueue.add(cmd_pick);
                     country.population += fieldItem.output_fill;
                  }
                  else
                  {
                     System.out.println("WARNING!!! max population reached: " + country.toString() + " population="+ country.population + " max-population="+ country.max_population);
                  }
               }
               else if(this.startContracts)
               {
                  if (fieldItem.isSubwayTrain())
                  {
                     // Reschedule idle train Subway train
                     System.out.println("Reschedule train: " + fieldItem);
                     final Command put = CommandFactory.put(country.room_id, fieldItem.id, Contract.train_subway_rush_hour1);
                     this.postCommand(myProfile, country.room_id, put);
                  }
                  else if (contractMap.containsKey(fieldItem.name))
                  {
                     final String contractName = contractMap.get(fieldItem.name);
                     System.out.println("Starting contract for: " + fieldItem + ", contract: " + contractName);
                     final Command put = CommandFactory.put(country.room_id, fieldItem.id, contractName);
                     this.postCommand(myProfile, country.room_id, put);
                  }
               }
            }
            break;

            case CityItem.state_busy: // Contract helped by other user
               System.out.println("Skip: {" + fieldItem + "}");
               break;

            case CityItem.state_contract_completed: // production: contract ready
               {
                  if(fieldItem.isProduction())
                  {
                     System.out.println("  Pick: " + fieldItem);
                     Command cmd_pick = CommandFactory.pick(country, fieldItem);
                     commandQueue.add(cmd_pick);

                     if( contractMap.containsKey(fieldItem.name) )
                     {
                        final String contractName = contractMap.get(fieldItem.name);
                        System.out.println("  Starting contract for: " + fieldItem + ", contract: " + contractName);
                        final Command cmd = CommandFactory.put(country.room_id, fieldItem.id, contractName);
                        commandQueue.add(cmd);
                     }
                  }
                  else
                  {
                     // System.out.println("Skip: " + fieldItem);
                  }
               }
               break;

            case CityItem.state_gold_completed: // Ready to take gold coins (clean)
               {
                  Command cmd_clean = CommandFactory.clean(country.room_id, fieldItem.id);
                  System.out.println("Clean item: " + fieldItem);
                  commandQueue.add(cmd_clean);
               }
               break;

            case CityItem.state_contract_expired: // Contract Expired?
               {
                  System.out.println("Warning, Contract expired, doing pick: " + fieldItem);
                  Command cmd_pick = CommandFactory.pick(country.room_id, fieldItem.id);
                  commandQueue.add(cmd_pick);
               }
               break;

            default:
               System.out.println("State?: " + fieldItem);
               break;
         }
      }
      this.postCommand(myProfile, country.room_id, commandQueue);
   }

   private void helpFriendCountry(UserProfile myProfile, Friend friend) throws IOException, InterruptedException
   {
      System.out.println("  Helping Friend: id=" + friend.id + " first_name=" + friend.first_name +  " city_name=" + friend.city_name + " level=" + friend.level);

      for(Map.Entry<String, Room> roomEntry : friend.getOwnerRoomInformation().rooms.entrySet())
      {
         if(friend.help_points==0)
         {
            System.out.println("    Friend " +  friend + " out of help points.");
            break;
         }

         if(!roomEntry.getValue().available)
         {
            System.out.println("    Skip room " + roomEntry.getKey() + ", not available");
            continue;
         }

         System.out.println("    Checking room: id=" + roomEntry.getKey() + " first_name=" + friend.first_name +  " city_name=" + friend.city_name + " level=" + friend.level);
         final int roomId = Room.getId(roomEntry.getKey());
         Country friendCountry = client.postUserStat(myProfile, roomId, friend);
         this.helpFriendCountry(myProfile, friend, friendCountry);
      }
   }

   private void helpFriendCountry(UserProfile myProfile, Friend friend, Country friendCountry) throws IOException, InterruptedException
   {
      System.out.println("    Checking room #" +  friendCountry.room_id + " for " + " first_name=" + friend.first_name +  " city_name=" + friend.city_name);

      if (friendCountry.owner_id != friend.id)
         throw new RuntimeException("friendCountry.owner_id != friend.id");

      ArrayList<Command> commandQueue = new ArrayList<Command>();
      for (CityItem fieldItem : friendCountry.fields)
      {
         if(friend.help_points<1)
            break;
         switch (fieldItem.state)
         {
            case CityItem.state_idle: // Nothing special?
               break;

            case CityItem.state_constructing:
            case CityItem.state_busy: // Contract pending?
               if(fieldItem.isProduction())
               {
                  System.out.println("    Apply help to speed-up contract for: " + fieldItem.name + " (id=" + fieldItem.id + ") in room #" + friendCountry.room_id);
                  Command cmd_help = CommandFactory.help(friendCountry, fieldItem);
                  commandQueue.add(cmd_help);
                  --friend.help_points;
               }
               else if(!fieldItem.isResidential())
               {
                  {
                     System.out.println("    Cannot help: " + fieldItem.name + " (id=" + fieldItem.id + "), not sure if it is producing anything");
                  }
               }
               break;

            case CityItem.state_contract_expired: // Contract Expired
            {
               System.out.println("    Help recover contract for: " + fieldItem.name + " (id=" + fieldItem.id + ") in room #" + friendCountry.room_id);
               Command cmd_help = CommandFactory.help(friendCountry, fieldItem);
               commandQueue.add(cmd_help);
               --friend.help_points;
               break;
            }

            default:
               System.out.println("State?: " + fieldItem.name + " (id=" + fieldItem.id + ") has state " + fieldItem.state);
               break;
         }
      }
      this.postCommand(myProfile, friendCountry.room_id, commandQueue);
   }

   private Country postCommand(UserProfile myProfile, int room_id, Collection<Command> commandQueue) throws IOException, InterruptedException
   {
      if(commandQueue.isEmpty())
         return null;
      Command[] array = commandQueue.toArray (new Command[commandQueue.size ()]);
      return this.postCommand(myProfile, room_id, array);
   }

   private Country postCommand(UserProfile myProfile, int room_id, Command... command) throws IOException, InterruptedException
   {
      Country country = this.client.postCommand(myProfile, room_id, command);
      if(country.ok != null)
      {
         System.out.println("  Command okay!");
      }
      else
      {
         System.out.println("  Error??????????");
      }
      printCountry(country);
      Thread.sleep(this.command_delay_ms);
      return country;
   }

   private void printCountry(final Country country)
   {
      if(country.barn != null)
      {
         String barnContent = "";
         for (BarnItem item : country.barn)
         {
            if(!barnContent.isEmpty())
            {
               barnContent += ", ";
            }
            barnContent += item.toString();
         }
         System.out.println("  Barn: " + barnContent);
      }

      if(!country.friends.isEmpty())
      {
         System.out.println("  Friends:");
         for (Friend friend : country.friends)
         {
            System.out.println("    Friend: id=" + friend.id + " name=" + friend.getPlayerName() + " level=" + friend.level);
         }
      }

      if(this.printFields && country.fields != null)
      {
         System.out.println("  Fields:");
         for (CityItem fieldItem : country.fields)
         {
            System.out.println("    Field: name="+ fieldItem.name + " id=" + fieldItem.id + " state=" + fieldItem.state + " x=" + fieldItem.x + " y=" + fieldItem.y);
         }
      }

      System.out.println("coins = " + country.coins + ", gold = " + country.gold + ", experience = " + country.experience +  " respect=" + country.respect);

      if(country.others != null)
      {
         System.out.println("Warning, got " + country.others.size() + " unmapped elements");
         for(Element element : country.others)
         {
            System.out.println("    Element: name=" + element.getTagName());
         }
      }
   }

   private static Map<String, String> makeAutoContractMap()
   {
      Map<String, String> map = new TreeMap<String, String>();

      map.put(CityItem.assemblyLine, Contract.notebooks);
      map.put(CityItem.carDealerShip, Contract.sport_cars);
      map.put(CityItem.experimentalEnergyLab, Contract.alternative_power_sources);
      map.put(CityItem.experimentalGreenHouse, Contract.square_watermelons);
      map.put(CityItem.householdGoodsFacility, Contract.bikes);
      map.put(CityItem.householdGoodsStore, Contract.grain_coffee);
      map.put(CityItem.mountain_hotel_stage1, Contract.horse_sled_dogs);
      map.put(CityItem.mountain_hotel_stage1, Contract.horse_sled_dogs);
      map.put(CityItem.airport_plane1_buildsite, Contract.airport_parachuting);
      map.put(CityItem.airport_plane6_buildsite, Contract.airport_mail
      );
      return map;
   }
}

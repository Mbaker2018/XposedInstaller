package rodinia.megapolis;

import rodinia.megapolis.api.UserProfile;
import rodinia.megapolis.api.entity.Friend;

import java.util.Comparator;
import java.util.TreeMap;

/**
 * Can be used to sort friends, will help the friend with lowest priority number first
 * Created by Rodinia on 27-8-2014.
 */
public class PrioritizeFriends implements Comparator<Friend>
{
   private final TreeMap<Long, UserProfile> userProfiles = new TreeMap<Long, UserProfile>();

   public PrioritizeFriends(UserProfile[] userProfiles)
   {
      for(UserProfile userProfile : userProfiles)
      {
         this.userProfiles.put(userProfile.userId, userProfile);
      }
   }

   @Override public int compare(Friend f1, Friend f2)
   {
      int f1_prio = 1000;
      int f2_prio = 1000;
      UserProfile f1_profile = userProfiles.get(f1.id);
      UserProfile f2_profile = userProfiles.get(f2.id);
      if(f1_profile != null)
      {
         f1_prio = f1_profile.priority;
      }
      if(f2_profile != null)
      {
         f2_prio = f2_profile.priority;
      }
      if(f1_prio != f2_prio)
      {
         return f1_prio - f2_prio;
      }
      int result = Long.valueOf(f2.respect_level).compareTo(Long.valueOf(f1.respect_level));
      return result != 0 ? result : Long.valueOf(f1.id).compareTo(Long.valueOf(f2.id));
   }
}

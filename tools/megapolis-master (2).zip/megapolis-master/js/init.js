head.load("js/lib/jquery.js",
					"js/lib/cycle.js",
					"js/common.js");
